#include <iostream>
#include "Jedi.h"
#include "Planet.h"
#include "GeneralFunctions.h"


int main()
{
	std::cout << "Welcome to Star Wars Universe !\n\n";
	testProgram();
	return 0;
}